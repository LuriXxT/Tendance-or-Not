<?php

require 'UtilisateursController.php';

$url = $_SERVER['REQUEST_URI'];
$methode =  $_SERVER['REQUEST_METHOD'];

$chemin=parse_url($url, PHP_URL_PATH);

echo $chemin;

if($chemin=='/TendanceOrNot/utilisateurs'){
    echo 'yes';
    /*function inscription_user($nom,$prenom,$mail,$mdp){

        $nom = $_POST["nom"];
        $prenom = $_POST["prenom"];
        $mail = $_POST["mail"];
        $mdp = $_POST["mdp"];
    }*/

    $nom = $_POST["nom"];
    $prenom = $_POST["prenom"];
    $mail = $_POST["mail"];
    $mdp = $_POST["mdp"];

    store($nom, $prenom, $mail, $mdp);
}
else
if ($chemin == '/utilisateurs/create')  {

    get_form_crea_utisateur();
}
else if (($chemin== '/utilisateurs') and ($methode == 'POST')) {

    $module = $_POST["Nom"];
    $note = $_POST["Prenom"];
    $commentaire = $_POST["Email"];
    $enseignant = $_POST["mdp"];

    store($nom, $note, $commentaire, $enseignant);
}else {
    require "Templates/template_Inscription.html";
}
/*
else if($chemin=='/Connexion'){
    echo "ok";
}
else if($chemin=='/Incription'){
    echo "ok";
}
else if($chemin=='/QSP'){
    echo "ok";
}
else if($chemin=='/CCN'){
    echo "ok";
}*/
?>