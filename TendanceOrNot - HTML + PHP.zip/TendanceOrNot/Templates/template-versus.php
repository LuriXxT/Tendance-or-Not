<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start();
error_reporting(E_ALL ^ E_WARNING);
echo $_SESSION['connecté'];

?>
<!doctype html>
<html lang="fr">

<head>
  <meta charset="utf-8">
  <title>Versus - Tendance Or Not</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  <link rel="stylesheet" href="/TendanceOrNot/Templates/versus.css" type="text/css">
  <link rel="icon" type="image/png" href="/TendanceOrNot/Templates/white.png" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.1.0/css/all.css">


</head>

<header>
  <a href="template-versus.php"><img src="/TendanceOrNot/Templates/white.png" class="img-fluid mx-auto d-block" alt="logo du site" width="400" height="400"></a>
</header>

<body>
  <nav class="navbar navbar-expand-sm">
    <div class="container-fluid">
      <a class="navbar-brand d-block d-sm-none" href="javascript:void(0)">Mon profil</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mynavbar">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <a class="nav-link" href="template-versus.php">| Versus |</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="template_classement_photo.php">| TOP 10 photos |</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="template-classement.php">| TOP 10 phototographes |</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="template_Profil.php">Mon profil</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="template_ContactezNous.php">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="template_QuiSommesNous.php">Qui sommes nous ?</a>
          </li>
        </ul>
        <form class="d-flex">
          <li class="nav-item btn btn-primary">
            <a class="nav-link" href="template_Inscription.php">Inscription</a>
          </li>
          <li class="nav-item btn btn-primary">
            <a class="nav-link" href="template_Connexion.php">Connexion</a>
          </li>
          <li class="nav-item btn btn-primary">
            <a class="nav-link" href="Déconnexion">Déconnexion</a>
          </li>
        </form>
      </div>
    </div>
  </nav>
  <br></br>


  <div class="tinder">
    <div class="tinder--status">
      <i class="fa fa-remove"></i>
      <i class="fa fa-heart"></i>
    </div>

    <div class="tinder--cards">
      <div class="tinder--card">
        <img src="/TendanceOrNot/Templates/mich.jpg">
        <h3>Carte de démo</h3>
        <p>Ceci une démo des cartes de swipe</p>
      </div>
      <div class="tinder--card">
        <img src="/TendanceOrNot/Templates/mich.jpg">
        <h3>Carte de démo</h3>
        <p>Ceci une démo des cartes de swipe</p>
      </div>
      <div class="tinder--card">
        <img src="/TendanceOrNot/Templates/mich.jpg">
        <h3>Carte de démo</h3>
        <p>Ceci une démo des cartes de swipe</p>
      </div>
      <div class="tinder--card">
        <img src="/TendanceOrNot/Templates/mich.jpg">
        <h3>Carte de démo</h3>
        <p>Ceci une démo des cartes de swipe</p>
      </div>
      <div class="tinder--card">
        <img src="/TendanceOrNot/Templates/mich.jpg">
        <h3>Carte de démo</h3>
        <p>Ceci une démo des cartes de swipe</p>
      </div>
    </div>

    <div class="tinder--buttons">
      <button id="nope"><i class="fa fa-remove"></i></button>
      <button id="love"><i class="fa fa-heart"></i></button>
    </div>
  </div>
  <script src='https://hammerjs.github.io/dist/hammer.min.js'></script>



  <script src="/TendanceOrNot/Templates/scipt.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>


</body>

<footer>
  <br></br>
  <br></br>
  <p>TendanceOrNot <img src="/TendanceOrNot/Templates/white.png" alt="logo"> All Rights Reserved.</p>
</footer>

</html>