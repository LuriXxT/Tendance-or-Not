<?php
session_start();
error_reporting(E_ALL ^ E_WARNING);
echo $_SESSION['connecté'];

?>
<!doctype html>
<html lang="fr">

<head>
  <meta charset="utf-8">
  <title>Profil - Tendance Or Not</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  <link rel="stylesheet" href="/TendanceOrNot/Templates/style_template_menu.css" type="text/css">
  <link rel="icon" type="image/png" href="/TendanceOrNot/Templates/white.png" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.1.0/css/all.css">

</head>

<header>
  <a href="template-versus.php"><img src="/TendanceOrNot/Templates/white.png" class="img-fluid mx-auto d-block" alt="logo du site" width="400" height="400"></a>
</header>

<body>
  <nav class="navbar navbar-expand-sm">
    <div class="container-fluid">
      <a class="navbar-brand d-block d-sm-none" href="javascript:void(0)">Mon profil</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mynavbar">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <a class="nav-link" href="template-versus.php">| Versus |</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="template_classement_photo.php">| TOP 10 photos |</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="template-classement.php">| TOP 10 phototographes |</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="template_Profil.php">Mon profil</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="template_ContactezNous.php">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="template_QuiSommesNous.php">Qui sommes nous ?</a>
          </li>
        </ul>
        <form class="d-flex">
          <li class="nav-item btn btn-primary">
            <a class="nav-link" href="template_Inscription.php">Inscription</a>
          </li>
          <li class="nav-item btn btn-primary">
            <a class="nav-link" href="template_Connexion.php">Connexion</a>
          </li>
          <li class="nav-item btn btn-primary">
            <a class="nav-link" href="Déconnexion">Déconnexion</a>
          </li>
        </form>
      </div>
    </div>
  </nav>
  <br></br>
  <div class="container border-0">
    <div class="row">
      <div class="col-sm-4">

        <h2>Mon profil</h2>
        <div class="card" style="width:400px;" style="margin:5px;">
          <img class="card-img-top" src="/TendanceOrNot/Templates/mich.jpg" alt="Card image" style="width:100%">
          <div class="card-body">
            <h4 class="card-title">Mich Mich</h4>
            <p class="card-text">Age : 47</p>
            <p class="card-text">Profession : photographe</p>
            <p class="card-text">Bio : coucou les copains =)</p>
            <a href="template_Modification.php" class="btn btn-primary">Modifier mon compte</a>
          </div>
        </div>
      </div>

      <div class="col-sm-4">

        <h2>Mes réseaux</h2>
        <div class="card" style="width:400px;" style="margin:5px;">
          <img class="card-img-top" src="/TendanceOrNot/Templates/tel.png" alt="Card image" style="width:100%">
          <div class="card-body">
            <p class="card-text">Instagram : fictif</p>
            <p class="card-text">likedin : fictif</p>
            <p class="card-text">Twitter : fictif</p>
          </div>
        </div>
      </div>

      <div class="col-sm-4">

        <h2>Mes badges</h2>
        <div class="card" style="width:400px;" style="margin:5px;">
          <img class="card-img-top" src="/TendanceOrNot/Templates/trophee.png" alt="Card image" style="width:100%">
          <div class="card-body">
            <h4 class="card-title">Mes trophées :</h4>
            <p class="card-text">0 0 0 0 0 0 0 </p>
            <p class="card-text">Mes points d'élo de la semaine :</p>
            <p class="card-text">1750 pts</p>
          </div>
        </div>
      </div>


      <div class="col-sm">
        <br></br>
        <h2>Ma galerie</h2>
        <div class="card" style="width:700px">
          <div class="file btn btn-lg btn-primary">
            Ajouter une photo sur le thème 1 -
            <input type="file" name="file" />
          </div>
        </div>
        <p></p>
        <div class="card" style="width:700px">
          <div class="file btn btn-lg btn-primary">
            Ajouter une photo sur le thème 2 -
            <input type="file" name="file" />
          </div>
        </div>
        <p></p>
        <div class="card" style="width:700px">
          <div class="file btn btn-lg btn-primary">
            Ajouter une photo sur le thème 3 -
            <input type="file" name="file" />
          </div>
        </div>
        <p></p>
        <div class="card" style="width:700px">
          <a href="template_Modification_Photos.php" class="btn btn-primary" id="ecart">Modifier mes photos</a>
        </div>
        <p></p>

        <div class="container border-0">
          <div class="row">
            <div class="col-sm-4">

              <div id="demo" class="carousel slide carousel-fade" data-bs-ride="carousel">

                <!-- Indicators/dots -->
                <div class="carousel-indicators">
                  <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
                  <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
                </div>

                <!-- The slideshow/carousel -->
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="/TendanceOrNot/Templates/mich.jpg" alt="Los Angeles" class="d-block" style="width:100%">
                    <div class="carousel-caption d-none d-md-block" style="opacity: 1;">
                      <h5>Thème 1</h5>
                      <p>Photo 1/2</p>
                    </div>
                  </div>

                  <div class="carousel-inner">
                    <div class="carousel-item">
                      <img src="/TendanceOrNot/Templates/mich.jpg" alt="Los Angeles" class="d-block" style="width:100%">
                      <div class="carousel-caption d-none d-md-block">
                        <h5>Thème 1</h5>
                        <p>Photo 2/2</p>
                      </div>
                    </div>

                  </div>

                  <!-- Left and right controls/icons -->
                  <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                  </button>
                  <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
                    <span class="carousel-control-next-icon"></span>
                  </button>
                </div>

              </div>

            </div>
            <div class="col-sm-4">

              <div id="carousel1" class="carousel slide carousel-fade" data-bs-ride="carousel">

                <!-- Indicators/dots -->
                <div class="carousel-indicators">
                  <button type="button" data-bs-target="#carousel1" data-bs-slide-to="0" class="active"></button>
                  <button type="button" data-bs-target="#carousel1" data-bs-slide-to="1"></button>
                </div>

                <!-- The slideshow/carousel -->
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="/TendanceOrNot/Templates/mich.jpg" alt="Los Angeles" class="d-block" style="width:100%">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Thème 2</h5>
                      <p>Photo 1/2</p>
                    </div>
                  </div>

                  <div class="carousel-inner">
                    <div class="carousel-item">
                      <img src="/TendanceOrNot/Templates/mich.jpg" alt="Los Angeles" class="d-block" style="width:100%">
                      <div class="carousel-caption d-none d-md-block">
                        <h5>Thème 2</h5>
                        <p>Photo 2/2</p>
                      </div>
                    </div>

                  </div>

                  <!-- Left and right controls/icons -->
                  <button class="carousel-control-prev" type="button" data-bs-target="#carousel1" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                  </button>
                  <button class="carousel-control-next" type="button" data-bs-target="#carousel1" data-bs-slide="next">
                    <span class="carousel-control-next-icon"></span>
                  </button>
                </div>

              </div>
            </div>
            <div class="col-sm-4">

              <div id="carousel2" class="carousel slide carousel-fade" data-bs-ride="carousel">

                <!-- Indicators/dots -->
                <div class="carousel-indicators">
                  <button type="button" data-bs-target="#carousel2" data-bs-slide-to="0" class="active"></button>
                  <button type="button" data-bs-target="#carousel2" data-bs-slide-to="1"></button>
                </div>

                <!-- The slideshow/carousel -->
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="/TendanceOrNot/Templates/mich.jpg" alt="Los Angeles" class="d-block" style="width:100%">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Thème 3</h5>
                      <p>Photo 1/2</p>
                    </div>
                  </div>

                  <div class="carousel-inner">
                    <div class="carousel-item">
                      <img src="/TendanceOrNot/Templates/mich.jpg" alt="Los Angeles" class="d-block" style="width:100%">
                      <div class="carousel-caption d-none d-md-block">
                        <h5>Thème 3</h5>
                        <p>Photo 2/2</p>
                      </div>
                    </div>

                  </div>

                  <!-- Left and right controls/icons -->
                  <button class="carousel-control-prev" type="button" data-bs-target="#carousel2" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                  </button>
                  <button class="carousel-control-next" type="button" data-bs-target="#carousel2" data-bs-slide="next">
                    <span class="carousel-control-next-icon"></span>
                  </button>
                </div>
              </div>
            </div>

</body>

<footer>
  <br></br>
  <br></br>
  <p>TendanceOrNot <img src="/TendanceOrNot/Templates/white.png" alt="logo"> All Rights Reserved.</p>
</footer>

</html>