<?php
include 'connection.php';

function inserer_utilisateur($nom,$prenom,$mail,$mdp) {
    global $mysqli;

    $insertion = mysqli_query($mysqli, "INSERT INTO utilisateurs(nom, prenom, mail, mdp) values('$nom','$prenom','$mail','$mdp')");

    $rows = mysqli_affected_rows($mysqli);
}

    function get_all_utilisateur(){
    
        global $mysqli;
    $res = mysqli_query($mysqli, "SELECT * FROM utilisateurs");
    
    if ($res == false) {
        echo "error";
    } else {
        $utilisateurs = mysqli_fetch_all($res, MYSQLI_ASSOC);
    }
    return $utilisateurs;
}

?>