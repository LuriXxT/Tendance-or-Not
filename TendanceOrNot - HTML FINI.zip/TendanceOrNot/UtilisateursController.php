<?php
    require_once 'modele.php';


    function lister_utilisateurs(){
        
        $utilisateur = get_all_utilisateur();

        require 'template_Admin.html';
    }

    ///////////////////////////////////////////////////////
    function get_form_crea_utisateur() {

        require 'template_Inscription.html';
    }

    ///////////////////////////////////////////////////////
    function store($nom,$prenom,$mail,$mdp) {

        inserer_utilisateur($nom,$prenom,$mail,$mdp);

    }

    ///////////////////////////////////////////////////////

    ?>